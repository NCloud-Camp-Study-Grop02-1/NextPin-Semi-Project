package com.nextpin.app.service;

import com.nextpin.app.dto.SaveCourseDto;

public interface SaveCourseService {
    void saveCourse(SaveCourseDto saveCourseDto);
}