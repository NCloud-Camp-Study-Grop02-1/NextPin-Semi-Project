package com.nextpin.app.dto;

public class SearchRequestDto {

    private String keyword;

    // Getter and Setter
    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
}

